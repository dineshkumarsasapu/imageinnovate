package com.imageinnovate.Imageinnovate;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ImageinnovateApplicationTests {

	@Test
	void contextLoads() {
	}

}
